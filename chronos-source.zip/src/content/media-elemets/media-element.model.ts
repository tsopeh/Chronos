export type MediaElement = HTMLVideoElement | HTMLAudioElement;
