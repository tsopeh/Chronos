# Chronos
Chronos is a audio/video playback speed regulator and the timestamp maker.
---
## Shortcuts: 
* Increase playback rate (by 0.25s): "alt" + 'L'
* Decrease playback rate (by 0.25s): "alt" + 'J'
* Place timestamp marker: "alt" + 'K'
* Reset playback rate: "alt" + 'R'
